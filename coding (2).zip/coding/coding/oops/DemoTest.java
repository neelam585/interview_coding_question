package oops;

import java.util.function.BiFunction;
import java.util.function.Function;

public class DemoTest {
    public static void main(String[] args){


    }

}
