package oops;

import java.util.ArrayList;
import java.util.List;

@FunctionalInterface
interface Adder<T>{
    void add(T element);
}
public class AddElementLambdaExample {
    public static void main(String[] args){
        List<String> items = new ArrayList<>();

        Adder<String> stringAdder = items::add;
        stringAdder.add("AAA");
        stringAdder.add("BBB");
        stringAdder.add("CCC");
        stringAdder.add("DDD");
        System.out.println(items);
    }
}
