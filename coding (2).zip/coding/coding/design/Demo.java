package design;

import java.lang.Integer;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Demo {
    public static void main(String[] args){

    }

}
