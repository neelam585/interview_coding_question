package design.factory;

public class ConcreteProductA implements Product{

    @Override
    public void create() {
        System.out.println("Product A is created");
    }
}
