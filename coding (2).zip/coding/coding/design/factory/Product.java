package design.factory;

public interface Product {
    void create();
}
