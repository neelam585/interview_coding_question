package LeatCode;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class Data {
 public static boolean isPalindrome(String input){
     int left = 0;
     int right = input.length()-1;
     System.out.println(right);
     while (left<right) {   //it run multiple time until condition false
         if (input.charAt(left) != input.charAt(right)) {
             return false;
         }
         left++;
         right--;
     }
     return true;
 }

    public static void main(String[] args) {
       String s = "madam";
       boolean result = isPalindrome(s);
       System.out.println(result);
  }

}
