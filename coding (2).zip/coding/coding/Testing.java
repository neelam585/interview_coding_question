import java.util.*;
import java.util.stream.*;

public class Testing {

   public  static void main(String[] args){



    }
}
