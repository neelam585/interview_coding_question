public record CustomerRecord(String name, String address, Long id) {

}
