package practiceOops;

public class Test {
    public static int squire(int a){
        return a*a;
    }
    public static void main(String[] args){
        int result = Test.squire(6);
        System.out.println(result);
    }
}
