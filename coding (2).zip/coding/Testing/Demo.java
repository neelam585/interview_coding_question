import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
public class Demo {

    public static void main(String[] args) {


    }
}
