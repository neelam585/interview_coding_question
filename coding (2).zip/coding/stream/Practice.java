import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import static java.lang.String.valueOf;
public class Practice {
public static void main(String[] args){
    String str4 = "CAPGEMINI";
   long count = str4.chars().mapToObj(i->(char)i).filter(c->c =='I').count();
System.out.println(count);
    List<Integer> numbers = Arrays.asList(2,5,1,4,7,1,8,1,3,9,1);
    Integer num = numbers.stream().max(Integer::compare).get();
    Integer min = numbers.stream().sorted().findFirst().get();
    List<Integer> removeMinMax = numbers.stream().filter(n->!n.equals(min) && !n.equals(num)).distinct().toList();
    System.out.println(removeMinMax);
    List<Integer> revNum = numbers.stream().sorted((a,b)->Integer.compare(b,a)).toList();
    Map<Integer,Long> freqency = numbers.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
            .entrySet().stream().filter(entry -> entry.getValue()>1)
            .collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue));


AdderNum<Integer> adderNum = (a,b)->a+b;
System.out.println(adderNum.add(4,5));


}
}
@FunctionalInterface
interface AdderNum<T>{
    T add(T a, T b);
}
