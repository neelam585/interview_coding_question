import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.*;
public class Demo2 {

    public static void main(String[] args) {
        String str = "swiss";
        Map<Character, Long> data = str.chars().mapToObj(i->(char)i)
                .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));

       Character nonRepeatChar = data.entrySet().stream()
                .filter(entry->entry.getValue()==1)
                .map(Map.Entry::getKey)
                .findFirst().get();
               // .collect(Collectors.toList());
        System.out.println(nonRepeatChar);

        String strTwo = "telCo";
        String result = strTwo.chars().mapToObj(i->(char)i)
                .map(c->Character.isUpperCase(c)? c.toLowerCase(c) : c.toUpperCase(c))
                .map(String::valueOf).collect(Collectors.joining());
        System.out.println(result);


    }

}
