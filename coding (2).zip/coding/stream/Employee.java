import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.*;

class Employee {
    private String name;
    private String department;
    private double salary;

    // Constructor
    public Employee(String name, String department, double salary) {
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    // Getters
    public String getDepartment() {
        return department;
    }

    public double getSalary() {
        return salary;
    }


        public static void main(String[] args) {
            List<Employee> employees = Arrays.asList(
                    new Employee("Alice", "HR", 50000),
                    new Employee("Bob", "IT", 70000),
                    new Employee("Charlie", "HR", 60000),
                    new Employee("David", "IT", 80000),
                    new Employee("Eve", "Finance", 75000)
            );


            Double averageSalary = employees.stream().mapToDouble(Employee::getSalary).average().getAsDouble();

            Map<String, Double> averageSalaries = employees.stream()
                    .collect(Collectors.groupingBy(
                            Employee::getDepartment,
                            Collectors.averagingDouble(Employee::getSalary)
                    ));

            averageSalaries.forEach((dept, avgSalary) ->
                    System.out.println(dept + ": " + avgSalary)
            );
        }
}
