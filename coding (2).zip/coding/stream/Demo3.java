import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
public class Demo3 {
 public static void display(){
  //4! = 4,3,2,1
 }

public static void main(String[] args){


 }
}
