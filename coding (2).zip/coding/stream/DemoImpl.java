import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/*@FunctionalInterface
public interface MyInterface<T> {
    void add(T element );
}*/

public class DemoImpl{
    public static int testMethod() {
        try {
            int n = 10/0;
            return 10;
        }catch (Exception e) {
                return 30;

        } finally {
           //return 20;
           //System.out.println("finaly block");
        }
    }
    public static Boolean isPrime(int n){
        // n
        return IntStream.range(2,n).noneMatch(i->n%i ==0);
    }
    public static void main(String[] args){

        Executor executor = Executors.newFixedThreadPool(100);
        //Executor executor1 = Executors.newCachedThreadPool(10);


        /*List<Integer> item = new ArrayList<>();
        MyInterface<Integer> adder = item::add;
        adder.add();*/
        List<Integer> numbers = Arrays.asList(4, 5, 6, 7, 4, 5, 8, 9, 4, 6, 6);
        Map<Integer,Long> frequency = numbers.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
        List<Integer> dupElement = frequency.entrySet().stream().filter(entry ->entry.getValue()>1)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
        System.out.println(dupElement);

        DemoImpl demo = new DemoImpl();
        demo.testMethod();



    }


}
