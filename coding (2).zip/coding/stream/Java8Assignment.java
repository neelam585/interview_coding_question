import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Java8Assignment {
    public static String reverseWord(String input){
        List<String> words = Arrays.asList(input.split(" "));
        Collections.reverse(words);
        return words.stream().collect(Collectors.joining(" "));
    }

    public static void main(String[] args){
        String strr = "I love india";
        String result = reverseWord(strr);
        System.out.println(result);


        List<Integer> num = Arrays.asList(1,2,3,4,5,6,7,8,9);
        List<Integer> even = num.stream().filter(n->n%2==0).toList();

        List<Integer> num2 = Arrays.asList(111,122,321,231,132);
        List<Integer> startwith1 = num2.stream().map(String::valueOf).filter(s->s.startsWith("1"))
                .map(Integer::valueOf).toList();

        List<Integer> number = Arrays.asList(3,2,3,4,5,5,2,2,6,6,9,9,6,7,8,9);


        Map<Integer, Long> duplicateElement = number.stream().collect(Collectors.groupingBy(
                Function.identity(), Collectors.counting()))
                .entrySet().stream()
                .filter(entry->entry.getValue()>1)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        List<Integer> dupElement = number.stream().collect(Collectors.groupingBy(
                        Function.identity(), Collectors.counting()))
                .entrySet().stream()
                .filter(entry->entry.getValue()>1)
                .map(Map.Entry::getKey).toList();



        Integer firstNum = num.stream().findFirst().get();
        System.out.println(firstNum);

        long count = number.stream().distinct().count();

        Integer maxValue = number.stream().max(Integer::compare).get();
        Integer maxValue2 = number.stream().sorted((a,b)->Integer.compare(b,a)).findFirst().get();

        String str = "Java is a awesome programming";
        Map<Character, Long> frequency = str.chars().mapToObj(i->(char)i)
                .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));

        Optional<Character> firstRepeatingChar = frequency.entrySet().stream()
                .filter(entry->entry.getValue()>1)
                .map(Map.Entry::getKey)
                .findFirst();

        Optional<Character> firstNonRepeatingChar = frequency.entrySet().stream()
                .filter(entry->entry.getValue() == 1)
                .map(Map.Entry::getKey)
                .findFirst();

        List<Integer> sortNumber = number.stream().sorted().collect(Collectors.toList());

        String company = "CAPGEMINI";
        long character = company.chars().mapToObj(i->(char)i).filter(ch->ch == 'I').count();

        List<Integer> descOrder = number.stream().sorted(Comparator.comparing(Integer::reverse)).toList();

        Stream<String> stream1 = Stream.of("Java","Python", "Php");
        Stream<String> stream2 = Stream.of("Spring", "Spring Boot", ".NET");

        Stream<String> joinStream = Stream.concat(stream1,stream2);
        //System.out.println(joinStream); not correct
        joinStream.forEach(n->System.out.println(n));

        List<String> str1 = Arrays.asList("Java","Python", "Php", "Git", "Kubernetes");
        List<String> str2 = Arrays.asList("Spring", "Spring Boot", ".NET");
        List<String> concatnate = Stream.of(str1,str2).flatMap(List::stream).toList();

        System.out.println(concatnate);

        long countLength = str1.stream().filter(s->s.length()>5).count();

        int[] numInt = {2,3,34,5,5,4,3,3,3 };
        Map<Integer, Long> frequencyNum = Arrays.stream(numInt).boxed()
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
        System.out.println(frequencyNum);

       Thread thread = new Thread(()->{
           System.out.println("Thread is running using Lambda expression !");
       });
//-----------------------------------------------------------------------------
       MyFunction myFunction = ()->{
         System.out.println("This is functional interface");
       };
       myFunction.display();
//------------------------------------------------------------------------------
        List<String> country = Arrays.asList("USA", "Japan", "France", "Germany", "Italy", "U.K.","Canada");
        List<String> uppercase = country.stream().map(String::toUpperCase).collect(Collectors.toList());
        System.out.println(uppercase);
//-------------------------------------------------------------------------------------
        List<Integer> integers = Arrays.asList(9, 10, 3, 4, 7, 3, 4);
        List<Integer> squireOfUniqueNum = integers.stream().distinct().map(n->n*n).collect(Collectors.toList());
        //------------------------------------------------------------------------------

        int[] num3 = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};
        long counts = Arrays.stream(num3).count();
        System.out.println(counts);
        Optional<Integer> min = Arrays.stream(num3).boxed().sorted().findFirst();
        Optional<Integer> max = Arrays.stream(num3).boxed().max(Integer::compare);
        Optional<Integer> max2ndNum = Arrays.stream(num3).boxed()
                .sorted((a,b)->Integer.compare(b,a)).skip(1).findFirst();

        Integer sum = Arrays.stream(num3).boxed().reduce(0,(a,b)->a+b);

        //Double avg = Arrays.stream(num3).boxed().
        double average = IntStream.of(num3).average().orElse(0);
        System.out.println(average);

        List<Integer> integerss = Arrays.asList(9, 10, 3, 4, 7, 3, 4);
        double avg = integerss.stream().mapToDouble(n->n).average().getAsDouble();
        System.out.println("Average: " +avg);
//-------------------------------------------------------------------------------
        //Given String str="telCo" Toggle it to str=TELcO
        String str4 = "telCo";
        String lowerToUpper = str4.chars().mapToObj(i->(char)i)
                .map(c->c.isUpperCase(c) ? c.toLowerCase(c): c.toUpperCase(c))
                .map(String::valueOf)
                .collect(Collectors.joining());
        System.out.println("lowerToUpper: "+lowerToUpper);

        //put all zero in left side
        List<Integer> input = Arrays.asList(3,0,4,0,2,8,0,9);
        List<Integer> zeroInLeft = Stream.concat(
                input.stream().filter(i->i ==0),
                input.stream().filter(i->i !=0)).collect(Collectors.toList());
        System.out.println(zeroInLeft);


        List<Integer> num0 = num.stream().filter(n->n==0).toList();
        System.out.println(num0);
        List<Integer> notZero = num.stream().filter(n->n!=0).sorted().toList();
        System.out.println(notZero);
        List<Integer> join = Stream.of(num0,notZero).flatMap(List::stream).toList();
        System.out.println("Join: "+join);
       // ---------------------------------------------------
        // all one one side

            List<Integer> numbers = Arrays.asList(2,5,1,4,7,1,8,1,3,9,1);

            List<Integer> findOne = numbers.stream().filter(n->n ==1).collect(Collectors.toList());

            List<Integer> findNum = numbers.stream().filter(n->n !=1).collect(Collectors.toList());
            List<Integer> combine = Stream.of(findOne,findNum).flatMap(List::stream).sorted().collect(Collectors.toList());
            System.out.println(combine);
        //-----------------------------------------------------------
        String strrr = "aadabcscd";
        // abcd , remove duplicate
        String distinct = strrr.chars().mapToObj(i->String.valueOf((char)i)).distinct().sorted().collect(Collectors.joining());
        String unique1 = strrr.chars().mapToObj(i->(char)i).map(String::valueOf).distinct().sorted().collect(Collectors.joining());
        System.out.println(distinct);
        //----------------------------------------------------------
        List<String> strings = Arrays.asList("Sita","Gita", "Rita","Sita", "Amit", "Amit","Bananawwww");
        // length of longest word
       List<Integer> strLength = strings.stream().map(String::length).toList();
       Integer len = strLength.stream().sorted((a, b)->Integer.compare(b,a)).findFirst().get();
       System.out.println("length of longest word: "+len);

        //remove the duplicate
        List<String> unique = strings.stream().distinct().toList();
        //--------------------------------------------------------
        List<String> fruits = Arrays.asList("xx","Bananawwww","Apple","Grapssa","Orange");
        Collections.reverse(fruits); //[Orange, Grapssa, Apple, Bananawwww, xx]

        List<String> reWord = fruits.stream().collect(Collectors.toList());
        System.out.println("List in reverse order "+reWord); // [Orange, Grapssa, Apple, Bananawwww, xx]
        List<String> sortedFruits = fruits.stream().sorted(Comparator.comparing(String::length)).toList();
        System.out.println(sortedFruits); //[xx, Apple, Orange, Grapssa, Bananawwww]
        List<Integer> lenn = fruits.stream().map(String::length).toList();
        System.out.println(lenn);


        //----------------------------------------------------------
        // Integer addition
        Adder<Integer> intAdder = (a, b) -> a + b;
        System.out.println("Sum (int): " + intAdder.add(10, 20));
        Volume<Integer> v = (a,b,c)->a*b*c;
        System.out.println(v.calculate(10,5,4));

    }

}

@FunctionalInterface
interface MyFunction{
    void display();
}

@FunctionalInterface
 interface Adder<T> {
    T add(T a, T b);
}
@FunctionalInterface
interface Volume<T>{
    T calculate(T a, T b, T c);
}