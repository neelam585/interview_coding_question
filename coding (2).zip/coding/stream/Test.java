import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Test {
    // length of an array
    // sum of elements
    // avg of elements
    // finds the smallest element
    // concat {1,2,3,4,5}; and {8,2,6,7,4,5}; write java code. use arraycopy
    // check given array in sorted order or not.

    public static void main(String[] args) {
        int[] number = {1, 2, 3, 4, 5};

        int[] array1 = {1, 2, 3, 4, 5};
        int[] array2 = {8, 2, 6, 7, 4, 5};

       int[] result = new int[array1.length+array2.length];
       System.arraycopy(array1,0, result,0, array1.length);
       System.arraycopy(array2,0, result, array1.length, array2.length);
       System.out.println(Arrays.toString(result));
       System.out.println(number.length);
       System.out.println("Sum:"+sumArray(number));
       System.out.println(("smallest: "+smallestElementInArray(number)));
       System.out.println("Sorted: "+sortedArray(array2));

    }
    public static int sumArray(int[] array){
        int sum = 0;
        for(int i=0; i<array.length; i++){
            sum = sum+array[i];

        }
        return sum;
    }
    public static int smallestElementInArray(int[] array){
      int smallest = array[0];
      for(int i=1; i<array.length; i++){
          if(smallest > array[i]){
              smallest = array[i];
          }
      }
      return smallest;
    }

    public static boolean sortedArray(int[] array){
        for(int i=0; i<array.length-1; i++){
            if(array[i] > array[i+1]){
                return false;
            }
        }
        return true;
    }


}
